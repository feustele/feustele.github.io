public class Farkle{
    Player activePlayer = new Player("Emma Feustel");
    public String NAME;
    public int SCORE;
    public int SUBTOTAL;
    public int NUMBER_OF_TURNS;
    private static final int WINNING_SCORE = 10000;
    private static final int STRAIGHT = 3000;
    private static final int THREE_PAIRS = 1500;
    private static final int FOUR_OF_A_KIND = 1300;
    private static final int FIVE_OF_A_KIND = 2000;
    private static final int SIX_OF_A_KIND = 3000;
    private static final int THREE_ONES = 1000;
    private static final int THREE_TWOS = 200;
    private static final int THREE_THREES = 300;
    private static final int THREE_FOURS = 400;
    private static final int THREE_FIVES = 500;
    private static final int THREE_SIXES = 600;
    int ONES = 100;
    int FIVES = 50;
    public boolean allowedToRoll;
    public boolean allowedToPass;
    public boolean initialRoll;
    public boolean playerFarkled;

    private int tally[];
    private GVdie[] dice;
    public Player[] players;

    public String getName(){
        return NAME;
    }
    public int getScore(){
        return SCORE;
    }
    public int getSubtotal(){
        return SUBTOTAL;
    }
    public int getTurns(){
        return NUMBER_OF_TURNS;
    }
    public void setName(String n){
        NAME = n;
    }
    public void setScore(int s){
        SCORE = s;
    }
    public void setSubtotal(int s){
        SUBTOTAL = s;
    }
    public void setTurns(int t){
        NUMBER_OF_TURNS = t;
    }
    public void addToSubtotal(int amt){
        SUBTOTAL = SUBTOTAL + amt;
    }
    public void updateScore(){
        SCORE = SCORE + SUBTOTAL;
        SUBTOTAL = 0;
        NUMBER_OF_TURNS++;
    }
    public Farkle(){
        dice = new GVdie [6];
        for (int i = 0; i < 6; i++){
            dice [i] = new GVdie();
        }
        tally = new int[7];
        String [] names = {"Ada Lovelace", "Grace Hooper", "Alan Turing"}; players = new Player [3];
        for (int i = 0 ; i < 3 ; i++){
            players [i] = new Player (names [i]);
        }
        resetGame();
    }
    public Player getActivePlayer(){
        return activePlayer;
    }
    public boolean gameOver(){
        return activePlayer.getScore() >= WINNING_SCORE;
    }
    public GVdie[] getDice (){
        return dice;
    }
    private void tallySelectedDice(){
        for (int i = 0; i < tally.length; i++){
            tally [i] = 0;
        }
        for (int i = 0; i < dice.length; i++){
            if (dice [i].isSelected()){
                int value = dice[i].getValue();
                tally[value]++;
            }
        }
    }
    private void tallyUnscoredDice(){
        int unscoreddice = 0;
        for (int i = 0; i < tally.length; i++){
            tally [i] = 0;
        }
        for (int i = 0; i < dice.length; i++){
            if (!dice [i].isSelected()){
                unscoreddice = dice[i].getValue();
                tally[unscoreddice]++;
            }
        }
    }
    private boolean wereDiceSelected(){
        int truechecker = 0;
        for (int i = 0; i < dice.length; i++){
            if (dice [i].isSelected()){
                truechecker++;
            }
        }
        if (truechecker > 0){
            return true;
        }
        else{
            return false;
        }
    }
    public boolean hasStraight(){
        return tally [1] == 1 && tally [2] == 1 && tally [3] == 1 && tally [4] == 1 && tally [5] == 1 && tally [6] == 1;
    }
    public boolean hasThreePairs(){
        int count2s = 0;
        for (int i = 0; i < tally.length; i++){
            if (tally [i] == 2){
                count2s++;
            }
        }
        return count2s == 1 && hasMultiples(4) || count2s == 3;
    }
    private boolean hasMultiples(int numberTimes){
        boolean isMultiples = false;
        for (int i = 0; i < tally.length; i++){
            if (tally [i] == numberTimes){
                isMultiples = true;
            }
        }
         return isMultiples;
    }
    private void diceSelectedToScored(){
        for (int i = 0; i < dice.length; i++){
            if (dice[i].isSelected()){
                dice[i].setScored(true);
                dice[i].setSelected(false);
            }
        }
    }
    private void nextTurn(){
        initialRoll = true;
        allowedToPass = false;
        allowedToRoll = true;
        for (int i = 0; i < dice.length; i++){
            dice[i].setBlank();
            dice[i].setSelected(false);
            dice[i].setScored(false);
        }
    }
    public void newGame(){
        activePlayer.setSubtotal(0);
        activePlayer.setScore(0);
        activePlayer.setTurns(0);
        allowedToRoll = true;
        setActivePlayer(0);
    }
    public void resetGame(){
        newGame();
        nextTurn();
    }
    public void scoreSelectedDice(){
        tallySelectedDice();
        if (hasStraight()){
            activePlayer.addToSubtotal(STRAIGHT);
        }
        else if(hasMultiples(6)){
            activePlayer.addToSubtotal(SIX_OF_A_KIND);
        }
        else if(hasMultiples(5)){
            activePlayer.addToSubtotal(FIVE_OF_A_KIND);
        }
        else if (hasThreePairs()){
            activePlayer.addToSubtotal(THREE_PAIRS);
        }
        else if(hasMultiples(4)){
            activePlayer.addToSubtotal(FOUR_OF_A_KIND);
        }
        if(tally[5] == 1 && !hasStraight() || 
        tally[5] == 2 && !hasThreePairs()){
            activePlayer.addToSubtotal(FIVES * tally[5]);
        }
        if(tally[1] == 1 && !hasStraight() || 
        tally[1] == 2 && !hasThreePairs()){
            activePlayer.addToSubtotal(ONES * tally[1]);
        }
        if(tally[1] == 3){
            activePlayer.addToSubtotal(THREE_ONES);
        }
        for (int i = 2; i < tally.length; i++){
            if (tally[i] == 3){
                activePlayer.addToSubtotal(i*100);
            }
        }
        diceSelectedToScored();
    }
    public void rollDice(){
        for (int i = 0; i < dice.length; i++){
              if (initialRoll = true || dice[i].isSelected()){
                scoreSelectedDice();
                allowedToPass = true;
                if (dice [i].isSelected() == false){
                    dice[i].roll();
                }
            }
        }
    }
    public void passDice(){
        scoreSelectedDice();
        activePlayer.updateScore();
        nextTurn();
    }
    public void selectDie (int id){
        dice[(id-1)].setSelected(true);
    }
    public void setAllDice (int [] values){
         for (int i = 0; i < dice.length; i++){
             while (dice[i].getValue() != values[i]){
                 dice[i].roll();
             }
         }
    }
    public String diceToString ( ){
        String DICE_STRING = "";
        for (int i = 0; i > dice.length; i++){
            DICE_STRING = (dice[i] + ", ");
        }
        return DICE_STRING;
    }
    public boolean playerFarkled(){
        tallyUnscoredDice();
        boolean helper = false;
        if (hasStraight()){
            helper = false;
        }
        else if (hasThreePairs()){
            helper = false;
        }
        else if (hasMultiples(3)){
            helper = false;
        }
        else if (hasMultiples(4)){
            helper = false;
        }
        else if (hasMultiples(5)){
            helper = false;
        }
        else if(hasMultiples(6)){
            helper = false;
        }
        else{
            if (tally[1] == 0 && tally[5] == 0){
                helper = true;
            }
        }
        return helper;
    }
    public boolean okToRoll(){
        return allowedToRoll;
    }
    public boolean okToPass(){
        return allowedToPass;
    }
    public void setActivePlayer(int playerNum){
        if (playerNum == 1){
            activePlayer = players [0];
        }
        else if (playerNum == 2){
            activePlayer = players [1];
        }
        else{
            activePlayer = players [2];
        }
    }
}

    

