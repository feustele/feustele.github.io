
public class FarkleTest{ 
    public static void main(String [] args){ 
        int WINNING_SCORE = 10000;
        int STRAIGHT = 3000;
        int THREE_PAIRS = 1500;
        int FOUR_OF_A_KIND = 1300;
        int FIVE_OF_A_KIND = 2000;
        int SIX_OF_A_KIND = 3000;
        int THREE_ONES = 1000;
        int THREE_TWOS = 200;
        int THREE_THREES = 300;
        int THREE_FOURS = 400;
        int THREE_FIVES = 500;
        int THREE_SIXES = 600;
        String NAME;
        int SCORE;
        int SUBTOTAL;
        int NUMBER_OF_TURNS;
 
        Farkle game = new Farkle(); 
 
        System.out.println("\nTesting begins...");
        
        game.getActivePlayer().setSubtotal(200);
        game.getActivePlayer().setScore(500);
        game.getActivePlayer().setTurns(200);
        game.selectDie(3);
        game.resetGame();
        
        //testing straight 
        game.setAllDice(new int[] {2,4,5,6,1,3}); 
        for(int i=1; i<=6; i++){ 
            game.selectDie(i); 
        } 
        game.scoreSelectedDice(); 
        if(game.hasStraight()){
            game.addToSubtotal(STRAIGHT);
            if (game.SUBTOTAL != STRAIGHT){
                System.out.println("FAIL: Straight not scored correctly"); 
            }
        }      
        else{
            System.out.println("FAIL: Straight not scored correctly"); 
        }
 
        game.passDice();  
 
        //testing three pairs 
        
        game.setSubtotal(0);
        
        game.setAllDice(new int[] {2,2,5,5,4,4}); 
        for(int i=1; i<=6; i++){ 
            game.selectDie(i); 
        } 
        game.scoreSelectedDice(); 
        if(game.hasThreePairs()){
            game.addToSubtotal(THREE_PAIRS);
            if (game.SUBTOTAL != THREE_PAIRS){
                System.out.println("FAIL: Three Pairs not scored correctly"); 
            }
        }      
        else{
            System.out.println("FAIL: Three Pairs not scored correctly"); 
        } 
        
        game.passDice();
        game.setSubtotal(0);
        
        game.setAllDice(new int[] {2,2,2,2,4,4}); 
        for(int i=1; i<=6; i++){ 
            game.selectDie(i); 
        } 
        game.scoreSelectedDice(); 
        if(game.hasThreePairs()){
            game.addToSubtotal(FOUR_OF_A_KIND);
            if (game.SUBTOTAL != FOUR_OF_A_KIND){
                System.out.println("FAIL: FOUR_OF_A_KIND not scored correctly"); 
            }
        }      
        else{
            System.out.println("FAIL: FOUR_OF_A_KIND not scored correctly"); 
        }   
        
        game.passDice(); 
        
        Farkle game2 = new Farkle();
        
        SUBTOTAL = 0;
        game2.setAllDice(new int[] {2,3,4,6,2,4}); 
        for(int i=1; i<=6; i++){ 
            game.selectDie(i); 
        } 
        game2.scoreSelectedDice();
        if(game.getSubtotal() == 0 ){ 
            System.out.println("Player Farkled"); 
        }
        
        Farkle game3 = new Farkle();
        
        String [] names = {"Rose Tyler", "Martha Jones", "Donna Noble"};
        for (int i = 0 ; i < 3 ; i++){
            game3.players [i] = new Player (names [i]);
        }
        
        game3.setActivePlayer(2);
        game3.getActivePlayer();
        
        System.out.println("Testing completed."); 
    } 
}
