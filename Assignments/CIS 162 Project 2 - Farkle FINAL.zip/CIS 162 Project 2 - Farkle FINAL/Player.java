
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player{
    public String NAME;
    public int SCORE;
    public int SUBTOTAL;
    public int NUMBER_OF_TURNS;
    public Player(String n){
        NAME = n;
    }
    public String getName(){
        return NAME;
    }
    public int getScore(){
        return SCORE;
    }
    public int getSubtotal(){
        return SUBTOTAL;
    }
    public int getTurns(){
        return NUMBER_OF_TURNS;
    }
    public void setName(String n){
        NAME = n;
    }
    public void setScore(int s){
        SCORE = s;
    }
    public void setSubtotal(int s){
        SUBTOTAL = s;
    }
    public void setTurns(int t){
        NUMBER_OF_TURNS = t;
    }
    public void addToSubtotal(int amt){
        SUBTOTAL = SUBTOTAL + amt;
    }
    public void updateScore(){
        SCORE = SCORE + SUBTOTAL;
        SUBTOTAL = 0;
        NUMBER_OF_TURNS++;
    }
    public void newGame(){
        SCORE = 0;
        SUBTOTAL = 0;
        NUMBER_OF_TURNS = 0;
    }
}
